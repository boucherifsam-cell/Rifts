package dev.rifters.client;

import dev.rifters.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public final class RiftersClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(RiftSovereignModel.LAYER, RiftSovereignModel::createBodyLayer);
        EntityRendererRegistry.register(ModEntities.RIFT_SOVEREIGN, RiftSovereignRenderer::new);
    }
}
