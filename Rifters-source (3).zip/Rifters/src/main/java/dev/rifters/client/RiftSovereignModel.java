package dev.rifters.client;

import dev.rifters.Rifters;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import dev.rifters.entity.RiftSovereign;

/**
 * The Rift Sovereign: a tall skeletal wraith with a ribcage, a heavy skull, two bent legs and a long tail.
 * Geometry and UVs come straight from the Blockbench model. Only the hierarchy was changed so it can be animated:
 * body (hips) carries torso, ribs, head and tail; the head pivots at the neck; the tail segments hang off the tail root.
 * Front of the model is -Z, the tail points to +Z.
 */
public final class RiftSovereignModel extends EntityModel<RiftSovereignRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(Rifters.id("rift_sovereign"), "main");
    private static final float TAU = (float) (Math.PI * 2.0);
    /**
     * In the Blockbench model the face is painted on the skull's EAST side, so it looked sideways and the boss seemed
     * to walk like a crab. Turning the skull a quarter turn puts the face on the front (-Z).
     * If it ever looks the wrong way round, change this to -PI/2 (or 0 to get the original orientation back).
     */
    private static final float HEAD_YAW = (float) (Math.PI / 2.0);

    private final ModelPart root;
    private final ModelPart body, torso, ribs, head, tail, tailMid, tailTip;
    private final ModelPart leftLeg, rightLeg, leftHip, leftShin, rightHip, rightShin;

    public RiftSovereignModel(ModelPart root) {
        super(root);
        this.root = root;
        body = root.getChild("body");
        torso = body.getChild("torso");
        ribs = body.getChild("ribs");
        head = body.getChild("head");
        tail = body.getChild("tail");
        tailMid = tail.getChild("tail_mid");
        tailTip = tail.getChild("tail_tip");
        leftLeg = root.getChild("left_leg");
        leftHip = leftLeg.getChild("hip");
        leftShin = leftLeg.getChild("shin");
        rightLeg = root.getChild("right_leg");
        rightHip = rightLeg.getChild("hip");
        rightShin = rightLeg.getChild("shin");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        CubeDeformation none = CubeDeformation.NONE;

        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(0.0F, 15.0F, 0.0F));

        body.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(12, 10).addBox(-1.0F, -9.0F, -1.0F, 2.0F, 7.0F, 2.0F, none)
                .texOffs(0, 10).addBox(-1.0F, -2.0F, -3.0F, 2.0F, 2.0F, 4.0F, none),
                PartPose.offset(0.0F, 0.0F, 1.0F));

        body.addOrReplaceChild("ribs", CubeListBuilder.create()
                .texOffs(28, 17).addBox(-1.0F, -8.0F, -2.0F, 2.0F, 1.0F, 1.0F, none)
                .texOffs(28, 15).addBox(-1.0F, -6.0F, -2.0F, 2.0F, 1.0F, 1.0F, none)
                .texOffs(28, 13).addBox(-1.0F, -4.0F, -2.0F, 2.0F, 1.0F, 1.0F, none)
                .texOffs(0, 16).addBox(-1.0F, -4.0F, -2.0F, 1.0F, 1.0F, 4.0F, none)
                .texOffs(10, 19).addBox(-1.0F, -6.0F, -2.0F, 1.0F, 1.0F, 4.0F, none)
                .texOffs(20, 0).addBox(-1.0F, -8.0F, -2.0F, 1.0F, 1.0F, 4.0F, none),
                PartPose.offset(0.0F, 0.0F, -1.0F));

        // The skull: "head" is the animated neck joint (nods and turns); "skull" only carries the fixed quarter turn
        // that moves the face from the east side to the front. (If the quarter turn sat on "head" itself, every nod
        // would tilt sideways, because Minecraft applies pitch before yaw.)
        PartDefinition head = body.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.5F, -9.0F, 0.5F));
        head.addOrReplaceChild("skull", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-2.5F, -5.0F, -2.5F, 5.0F, 5.0F, 5.0F, none),
                PartPose.rotation(0.0F, HEAD_YAW, 0.0F));

        PartDefinition tail = body.addOrReplaceChild("tail", CubeListBuilder.create()
                .texOffs(0, 27).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F, none),
                PartPose.offset(0.0F, -6.0F, 3.0F));
        tail.addOrReplaceChild("tail_base", CubeListBuilder.create()
                .texOffs(28, 5).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F, none),
                PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.7854F, 0.0F, 0.0F));
        tail.addOrReplaceChild("tail_mid", CubeListBuilder.create()
                .texOffs(28, 9).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F, none),
                PartPose.offsetAndRotation(0.0F, 1.0F, 1.0F, -1.2654F, 0.0F, 0.0F));
        tail.addOrReplaceChild("tail_tip", CubeListBuilder.create()
                .texOffs(8, 24).addBox(-2.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, none),
                PartPose.offsetAndRotation(1.0F, 1.0F, 3.0F, 0.0F, 0.0F, -0.2182F));

        PartDefinition leftLeg = root.addOrReplaceChild("left_leg", CubeListBuilder.create()
                .texOffs(20, 12).addBox(-1.0F, -2.0F, 5.0F, 2.0F, 5.0F, 2.0F, none),
                PartPose.offset(0.0F, 21.0F, -3.0F));
        leftLeg.addOrReplaceChild("hip", CubeListBuilder.create()
                .texOffs(16, 25).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F, none),
                PartPose.offsetAndRotation(0.0F, -6.0F, 4.0F, -0.7854F, 0.0F, 0.0F));
        leftLeg.addOrReplaceChild("shin", CubeListBuilder.create()
                .texOffs(0, 21).addBox(-1.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F, none),
                PartPose.offsetAndRotation(0.0F, -2.0F, 7.0F, 0.3054F, 0.0F, 0.0F));

        PartDefinition rightLeg = root.addOrReplaceChild("right_leg", CubeListBuilder.create()
                .texOffs(20, 5).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 5.0F, 2.0F, none),
                PartPose.offset(0.0F, 21.0F, -3.0F));
        rightLeg.addOrReplaceChild("shin", CubeListBuilder.create()
                .texOffs(20, 19).addBox(-1.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F, none),
                PartPose.offsetAndRotation(0.0F, -2.0F, 0.0F, -0.1745F, 0.0F, 0.0F));
        rightLeg.addOrReplaceChild("hip", CubeListBuilder.create()
                .texOffs(24, 25).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F, none),
                PartPose.offsetAndRotation(0.0F, -6.0F, 0.5F, -0.7854F, 0.0F, 0.0F));

        return LayerDefinition.create(mesh, 64, 64); // the PNG is 128x128: the same UVs, drawn at 2x resolution
    }

    // ------------------------------------------------------------------ animation

    private static float clamp01(float v) { return Mth.clamp(v, 0.0F, 1.0F); }
    private static float ease(float v) { v = clamp01(v); return v * v * (3.0F - 2.0F * v); }

    @Override
    public void setupAnim(RiftSovereignRenderState s) {
        super.setupAnim(s);
        // ---- dormant: a motionless, triumphant statue (no idle motion, no head tracking)
        if (s.dormant) {
            epicPose(1.0F);
            return;
        }
        final float rate = s.enraged ? 1.35F : 1.0F;
        final float t = s.ageInTicks * rate;
        final float walk = Mth.clamp(s.walkAnimationSpeed * 1.6F, 0.0F, 1.0F);
        final float wp = s.walkAnimationPos * rate;

        // ---- idle: slow breathing, ribs swell, tail drifts like it was underwater
        float breath = Mth.sin(t * 0.08F);
        body.xRot += breath * 0.02F;
        head.xRot += -breath * 0.03F;
        ribs.yScale += breath * 0.03F;
        ribs.zScale += breath * 0.05F;
        tail.yRot += Mth.sin(t * 0.07F) * 0.25F;
        tail.xRot += Mth.sin(t * 0.05F + 1.0F) * 0.08F;
        tailMid.yRot += Mth.sin(t * 0.07F - 0.9F) * 0.22F;
        tailTip.zRot += Mth.sin(t * 0.09F - 1.8F) * 0.3F;

        // ---- walk: long stalking strides along the body axis, lean into the step
        float c = Mth.cos(wp * 0.6662F), sn = Mth.sin(wp * 0.6662F);
        rightLeg.z += c * 2.2F * walk;
        rightLeg.y -= Math.max(0.0F, sn) * 1.6F * walk;
        leftLeg.z -= c * 2.2F * walk;
        leftLeg.y -= Math.max(0.0F, -sn) * 1.6F * walk;
        body.y += Math.abs(c) * 0.6F * walk;
        body.xRot += 0.1F * walk;
        tail.yRot += c * 0.35F * walk;

        // ---- skull follows the target
        head.yRot += Mth.clamp(s.yRot, -60.0F, 60.0F) * Mth.DEG_TO_RAD;
        head.xRot += Mth.clamp(s.xRot, -40.0F, 40.0F) * Mth.DEG_TO_RAD;

        // ---- melee bite: the skull lunges forward
        if (s.attackTime > 0.0F) {
            float bite = Mth.sin(s.attackTime * (float) Math.PI);
            head.z -= bite * 2.0F;
            head.xRot += bite * 0.5F;
            body.xRot += bite * 0.2F;
        }

        // ---- special attacks
        final float a = s.attackTick;
        switch (s.attackType) {
            case RiftSovereign.SWEEP -> animateSweep(a);
            case RiftSovereign.GAZE -> animateGaze(a);
            case RiftSovereign.CALL -> animateCall(a);
            case RiftSovereign.STEP -> animateStep(a);
            case RiftSovereign.WAKE -> animateWake(a);
            default -> { }
        }

        // ---- death: the bones give way
        if (s.deathTime > 0.0F) {
            float d = ease(s.deathTime / 18.0F);
            body.xRot += 0.9F * d;
            body.y += 5.0F * d;
            head.xRot += 0.7F * d;
            tail.xRot -= 0.6F * d;
            leftLeg.z += 1.5F * d;
            rightLeg.z -= 1.5F * d;
        }
    }

    /** The waiting pose: chest out, chin raised, legs braced wide, tail raised like a sceptre, ribs flared. */
    private void epicPose(float w) {
        body.xRot += -0.14F * w;
        body.y -= 0.4F * w;
        head.xRot += -0.38F * w;
        ribs.xScale += 0.3F * w;
        ribs.zScale += 0.25F * w;
        leftLeg.z += 1.4F * w;
        rightLeg.z -= 1.4F * w;
        tail.xRot += 1.05F * w;
        tailMid.xRot += 0.35F * w;
        tailTip.zRot += 0.25F * w;
    }

    /** Waking: the pose breaks, the skull is thrown back for a roar (shockwave at tick 14), then snaps forward. */
    private void animateWake(float t) {
        epicPose(1.0F - ease(t / 12.0F));
        float roar = ease((t - 6.0F) / 8.0F) * (1.0F - ease((t - 14.0F) / 10.0F));
        float thrust = t >= 14.0F ? Mth.lerp(clamp01((t - 14.0F) / 12.0F), 0.4F, 0.0F) : 0.0F;
        head.xRot += -0.9F * roar + thrust;
        body.xRot += -0.2F * roar + 0.25F * thrust;
        body.y += Mth.sin(t * 2.5F) * 0.3F * roar;
        ribs.xScale += 0.8F * roar;
        tail.yRot += Mth.sin(t * 0.9F) * 0.5F * clamp01((t - 12.0F) / 8.0F) * (1.0F - clamp01((t - 24.0F) / 12.0F));
    }

    /** Tail Sweep: coil up, whip the tail through a full turn, recover. Hit lands at tick 16. */
    private void animateSweep(float t) {
        float wind = ease(t / 16.0F);
        float spin = clamp01((t - 16.0F) / 10.0F);
        float rec = ease((t - 26.0F) / 8.0F);
        float coil = wind * (1.0F - ease(spin)) ;
        body.yRot += -1.1F * coil;
        body.xRot += -0.25F * wind * (1.0F - rec) + 0.2F * Mth.sin(spin * (float) Math.PI);
        body.y += 1.5F * wind * (1.0F - rec);
        head.xRot += -0.3F * coil;
        tail.xRot += 0.9F * wind * (1.0F - rec);          // tail lifts and stretches out
        tailMid.xRot += 0.5F * wind * (1.0F - rec);
        tailTip.zRot += 0.4F * wind * (1.0F - rec);
        ribs.xScale += 0.4F * wind * (1.0F - rec);
        if (t >= 16.0F && t < 26.0F) root.yRot = -spin * TAU;   // the whole skeleton spins with the tail
    }

    /** Rift Gaze: skull thrown back while the ribs flare and the legs brace; at tick 34 it snaps forward and fires. */
    private void animateGaze(float t) {
        float charge = ease(t / 34.0F);
        float rec = ease((t - 44.0F) / 8.0F);
        boolean fired = t >= 34.0F;
        float recoil = fired ? Mth.lerp(clamp01((t - 34.0F) / 14.0F), 1.0F, 0.0F) : 0.0F;
        float hold = (1.0F - rec);
        if (!fired) {
            head.xRot += -1.0F * charge;
            body.xRot += -0.3F * charge;
            head.zRot += Mth.sin(t * 1.6F) * 0.06F * charge;   // trembling
            body.y += Mth.sin(t * 2.1F) * 0.25F * charge;
        } else {
            head.xRot += 0.35F * recoil;
            body.xRot += 0.3F * recoil;
        }
        ribs.xScale += 0.7F * charge * hold;
        ribs.zScale += 0.5F * charge * hold;
        leftLeg.z += 1.2F * charge * hold;
        rightLeg.z -= 1.2F * charge * hold;
        tail.xRot += -0.2F * charge;
    }

    /** Rift Call: levitates, tail raised like a staff, ribs open to let the vexes out (summon at tick 24). */
    private void animateCall(float t) {
        float u = ease(t / 14.0F) * (1.0F - ease((t - 38.0F) / 8.0F));
        root.y -= 2.5F * u + Mth.sin(t * 0.3F) * 0.4F * u;
        tail.xRot += 1.35F * u;
        tailMid.xRot += 0.4F * u;
        body.xRot += -0.18F * u;
        head.xRot += -0.45F * u + Mth.sin(t * 0.5F) * 0.06F * u;
        ribs.xScale += 0.8F * u;
        ribs.zScale += 0.6F * u + Mth.sin(t * 0.9F) * 0.15F * u;
        leftLeg.xRot += 0.5F * u;
        rightLeg.xRot -= 0.4F * u;
    }

    /** Rift Step: folds into the rift (tick 12 = teleport), then unfolds behind the target. */
    private void animateStep(float t) {
        float k;
        if (t < 12.0F) k = Mth.lerp(ease(t / 12.0F), 1.0F, 0.05F);
        else k = Mth.lerp(ease((t - 12.0F) / 10.0F), 0.05F, 1.0F);
        root.xScale = k;
        root.zScale = k;
        root.yScale = Mth.lerp(0.5F, 1.0F, k);
        root.y += 24.0F * (1.0F - root.yScale);   // keep the feet on the ground while squashing
        body.xRot += 0.5F * (1.0F - k);
        head.xRot += 0.4F * (1.0F - k);
    }
}
