package dev.rifters.client;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.rifters.Rifters;
import dev.rifters.entity.RiftSovereign;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public final class RiftSovereignRenderer extends MobRenderer<RiftSovereign, RiftSovereignRenderState, RiftSovereignModel> {
    private static final Identifier TEXTURE = Rifters.id("textures/entity/rift_sovereign.png");
    /** The model is 24 px (1.5 blocks) tall; the boss is drawn 3x bigger (about 4.5 blocks). */
    public static final float SCALE = 3.0f;

    public RiftSovereignRenderer(EntityRendererProvider.Context context) {
        super(context, new RiftSovereignModel(context.bakeLayer(RiftSovereignModel.LAYER)), 1.1f);
    }

    @Override
    public RiftSovereignRenderState createRenderState() {
        return new RiftSovereignRenderState();
    }

    @Override
    public void extractRenderState(RiftSovereign entity, RiftSovereignRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.attackType = entity.getAttackType();
        state.attackTick = entity.getAttackTick() + (entity.getAttackType() == RiftSovereign.NONE ? 0.0f : partialTick);
        state.dormant = entity.isDormant();
        state.enraged = entity.getHealth() < entity.getMaxHealth() * 0.25f;
    }

    @Override
    public Identifier getTextureLocation(RiftSovereignRenderState state) {
        return TEXTURE;
    }

    @Override
    protected void scale(RiftSovereignRenderState state, PoseStack poseStack) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }
}
