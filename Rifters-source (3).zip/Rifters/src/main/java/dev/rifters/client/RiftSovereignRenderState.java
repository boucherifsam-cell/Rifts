package dev.rifters.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

/** Everything the model needs to animate the boss. Filled in by {@link RiftSovereignRenderer}. */
public class RiftSovereignRenderState extends LivingEntityRenderState {
    public int attackType;      // see RiftSovereign.NONE / SWEEP / GAZE / CALL / STEP
    public float attackTick;    // ticks since the attack started (with partial tick)
    public boolean enraged;     // below 25% health
    public boolean dormant;     // standing in its epic pose, waiting for the first blow
}
