package dev.rifters.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.rifters.Rifters;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

/** World-persistent state: realm instances, return points, tower chunks already built, bosses already spawned. */
public final class RiftersData extends SavedData {
    public record ReturnPoint(String dimension, double x, double y, double z, float yaw, float pitch) {
        public static final Codec<ReturnPoint> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.STRING.fieldOf("dim").forGetter(ReturnPoint::dimension),
                Codec.DOUBLE.fieldOf("x").forGetter(ReturnPoint::x),
                Codec.DOUBLE.fieldOf("y").forGetter(ReturnPoint::y),
                Codec.DOUBLE.fieldOf("z").forGetter(ReturnPoint::z),
                Codec.FLOAT.fieldOf("yaw").forGetter(ReturnPoint::yaw),
                Codec.FLOAT.fieldOf("pitch").forGetter(ReturnPoint::pitch)
        ).apply(i, ReturnPoint::new));
    }

    private static final Codec<RiftersData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.unboundedMap(Codec.STRING, Codec.INT).optionalFieldOf("instances", Map.of()).forGetter(d -> d.instances),
            Codec.unboundedMap(Codec.STRING, Codec.INT).optionalFieldOf("built", Map.of()).forGetter(d -> d.built),
            Codec.unboundedMap(Codec.STRING, ReturnPoint.CODEC).optionalFieldOf("returns", Map.of()).forGetter(d -> d.returns),
            Codec.LONG.listOf().optionalFieldOf("placed", List.of()).forGetter(d -> new ArrayList<>(d.placed)),
            Codec.LONG.listOf().optionalFieldOf("bosses", List.of()).forGetter(d -> new ArrayList<>(d.bosses)),
            Codec.INT.optionalFieldOf("next", 0).forGetter(d -> d.next)
    ).apply(i, RiftersData::new));

    public static final SavedDataType<RiftersData> TYPE =
            new SavedDataType<>(Rifters.id("state"), RiftersData::new, CODEC, DataFixTypes.LEVEL);

    private final Map<String, Integer> instances = new HashMap<>();
    private final Map<String, Integer> built = new HashMap<>();       // instance -> spawn height (relative)
    private final Map<String, ReturnPoint> returns = new HashMap<>();
    private final Set<Long> placed = new HashSet<>();
    private final Set<Long> bosses = new HashSet<>();
    private int next;

    private RiftersData() {}

    private RiftersData(Map<String, Integer> instances, Map<String, Integer> built, Map<String, ReturnPoint> returns,
                        List<Long> placed, List<Long> bosses, int next) {
        this.instances.putAll(instances);
        this.built.putAll(built);
        this.returns.putAll(returns);
        this.placed.addAll(placed);
        this.bosses.addAll(bosses);
        this.next = next;
    }

    public static RiftersData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(TYPE);
    }

    // ---- realm instances (one private cave per player) ----
    public int instanceFor(String player) {
        Integer existing = instances.get(player);
        if (existing != null) return existing;
        int id = next++;
        instances.put(player, id);
        setDirty();
        return id;
    }

    public boolean isBuilt(int instance) { return built.containsKey(Integer.toString(instance)); }

    public int spawnHeight(int instance) { return built.getOrDefault(Integer.toString(instance), 0); }

    public void markBuilt(int instance, int spawnHeight) {
        built.put(Integer.toString(instance), spawnHeight);
        setDirty();
    }

    public void setReturn(String player, ReturnPoint point) {
        returns.put(player, point);
        setDirty();
    }

    public ReturnPoint getReturn(String player) { return returns.get(player); }

    public void clearReturn(String player) {
        if (returns.remove(player) != null) setDirty();
    }

    // ---- tower bookkeeping ----
    public boolean isPlaced(long chunk) { return placed.contains(chunk); }

    public void markPlaced(long chunk) {
        if (placed.add(chunk)) setDirty();
    }

    public void forget(long chunk) {
        if (placed.remove(chunk)) setDirty();
    }

    public void forgetBoss(long site) {
        if (bosses.remove(site)) setDirty();
    }

    public boolean bossSpawned(long site) { return bosses.contains(site); }

    public void markBoss(long site) {
        if (bosses.add(site)) setDirty();
    }
}
