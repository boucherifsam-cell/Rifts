package dev.rifters.item;

import dev.rifters.realm.RealmManager;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.level.Level;

/**
 * Hold right click to open a rift. Used outside the realm it takes you to your own private cave;
 * used inside it brings you back to where you came from.
 */
public final class RiftOpenerItem extends Item {
    public static final int CHANNEL_TICKS = 40;

    public RiftOpenerItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        player.startUsingItem(hand);
        if (level instanceof ServerLevel serverLevel && player instanceof ServerPlayer serverPlayer) {
            RealmManager.prepare(serverPlayer, serverLevel);
            serverLevel.playSound(null, player.blockPosition(), SoundEvents.SCULK_CATALYST_BLOOM,
                    SoundSource.PLAYERS, 1.2f, 0.6f);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public ItemUseAnimation getUseAnimation(ItemStack stack) {
        return ItemUseAnimation.TOOT_HORN;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return CHANNEL_TICKS;
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remainingUseDuration) {
        if (!(level instanceof ServerLevel serverLevel)) return;
        int elapsed = CHANNEL_TICKS - remainingUseDuration;
        double radius = Math.max(0.3, 1.7 - elapsed * 0.034);
        double rise = 0.1 + elapsed * 0.045;
        for (int arm = 0; arm < 2; arm++) {
            double angle = elapsed * 0.42 + arm * Math.PI;
            serverLevel.sendParticles(ParticleTypes.SCULK_SOUL,
                    entity.getX() + Math.cos(angle) * radius, entity.getY() + rise, entity.getZ() + Math.sin(angle) * radius,
                    1, 0.0, 0.0, 0.0, 0.0);
        }
        if (elapsed % 6 == 0) {
            serverLevel.sendParticles(ParticleTypes.REVERSE_PORTAL, entity.getX(), entity.getY() + 1.0, entity.getZ(),
                    6, 0.4, 0.6, 0.4, 0.05);
        }
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (level instanceof ServerLevel serverLevel && entity instanceof ServerPlayer player) {
            RealmManager.toggle(player, serverLevel);
        }
        return stack;
    }
}
