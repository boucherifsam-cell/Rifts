package dev.rifters.util;

/** Tiny 3D value noise with trilinear smoothing. Output is roughly in [-1, 1]. */
public final class Noise3 {
    private final long seed;

    public Noise3(long seed) { this.seed = seed; }

    private double h(int x, int y, int z) { return Rng.unit(seed, x, y, z, 7) * 2.0 - 1.0; }

    private static double smooth(double t) { return t * t * (3.0 - 2.0 * t); }

    public double sample(double x, double y, double z) {
        int xi = (int) Math.floor(x), yi = (int) Math.floor(y), zi = (int) Math.floor(z);
        double u = smooth(x - xi), v = smooth(y - yi), w = smooth(z - zi);
        double c00 = lerp(h(xi, yi, zi), h(xi + 1, yi, zi), u);
        double c10 = lerp(h(xi, yi + 1, zi), h(xi + 1, yi + 1, zi), u);
        double c01 = lerp(h(xi, yi, zi + 1), h(xi + 1, yi, zi + 1), u);
        double c11 = lerp(h(xi, yi + 1, zi + 1), h(xi + 1, yi + 1, zi + 1), u);
        return lerp(lerp(c00, c10, v), lerp(c01, c11, v), w);
    }

    public double fbm(double x, double y, double z) {
        return sample(x, y, z) * 0.62 + sample(x * 2.03, y * 2.03, z * 2.03) * 0.28 + sample(x * 4.1, y * 4.1, z * 4.1) * 0.10;
    }

    private static double lerp(double a, double b, double t) { return a + (b - a) * t; }
}
