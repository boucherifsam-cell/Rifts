package dev.rifters.util;

/** Small deterministic hash-based random helpers (no state, safe to call from anywhere). */
public final class Rng {
    private Rng() {}

    public static long mix(long z) {
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    /** Uniform value in [0,1) from a seed and a 3D position plus a salt. */
    public static double unit(long seed, int x, int y, int z, int salt) {
        long h = mix(seed ^ mix(x * 0x9E3779B97F4A7C15L ^ mix(y * 0xC2B2AE3D27D4EB4FL ^ mix(z * 0x165667B19E3779F9L ^ salt))));
        return (h >>> 11) * 0x1.0p-53;
    }
}
