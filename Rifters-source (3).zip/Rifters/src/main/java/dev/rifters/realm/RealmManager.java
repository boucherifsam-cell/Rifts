package dev.rifters.realm;

import dev.rifters.Rifters;
import dev.rifters.data.RiftersData;
import dev.rifters.data.RiftersData.ReturnPoint;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Every player owns one sealed cave inside the shared "rift_realm" dimension. Caves sit on a grid, far apart,
 * and each one is generated from its own seed, so every realm is a different variation of the same theme.
 */
public final class RealmManager {
    public static final ResourceKey<Level> REALM = ResourceKey.create(Registries.DIMENSION, Rifters.id("rift_realm"));
    private static final int SPACING = 160;
    private static final int CENTER_Y = 10;
    private static final int BLOCKS_PER_TICK = 5000;
    private static final Identifier ADVANCEMENT = Rifters.id("the_deepest_and_darkest");

    private static final Map<Integer, Job> JOBS = new HashMap<>();
    private static final Map<UUID, Integer> WAITING = new HashMap<>();

    private RealmManager() {}

    private static final class Job {
        final int instance;
        final RealmGenerator.Plan plan;
        final BlockPos origin;
        int cursor;

        Job(int instance, RealmGenerator.Plan plan, BlockPos origin) {
            this.instance = instance; this.plan = plan; this.origin = origin;
        }

        boolean step(ServerLevel level) {
            int end = Math.min(plan.positions().size(), cursor + BLOCKS_PER_TICK);
            for (; cursor < end; cursor++) {
                BlockPos pos = BlockPos.of(plan.positions().getLong(cursor)).offset(origin);
                if (level.isOutsideBuildHeight(pos)) continue;
                BlockState state = plan.states().get(cursor);
                level.setBlock(pos, state, 18); // send to clients, skip neighbour shape updates (fast)
            }
            return cursor >= plan.positions().size();
        }
    }

    private static BlockPos centerOf(int instance) {
        return new BlockPos((instance % 1000) * SPACING, CENTER_Y, (instance / 1000) * SPACING);
    }

    private static boolean inRealm(ServerLevel level) { return level.dimension().equals(REALM); }

    /** Called when the player starts channelling: begins building their cave in the background if needed. */
    public static void prepare(ServerPlayer player, ServerLevel level) {
        if (inRealm(level)) return;
        MinecraftServer server = level.getServer();
        ServerLevel realm = server.getLevel(REALM);
        if (realm == null) return;
        RiftersData data = RiftersData.get(server);
        int instance = data.instanceFor(player.getStringUUID());
        if (!data.isBuilt(instance) && !JOBS.containsKey(instance)) {
            long seed = realm.getSeed() * 31L + instance * 7919L;
            JOBS.put(instance, new Job(instance, RealmGenerator.build(seed), centerOf(instance)));
        }
    }

    /** Called when the channel completes. */
    public static void toggle(ServerPlayer player, ServerLevel level) {
        MinecraftServer server = level.getServer();
        RiftersData data = RiftersData.get(server);
        String id = player.getStringUUID();

        if (inRealm(level)) {
            leave(player, server, data, id);
            return;
        }
        ServerLevel realm = server.getLevel(REALM);
        if (realm == null) {
            player.sendSystemMessage(Component.translatable("message.rifters.no_realm"), true);
            return;
        }
        int instance = data.instanceFor(id);
        // remember where we came from (only when leaving a normal dimension)
        data.setReturn(id, new ReturnPoint(level.dimension().identifier().toString(),
                player.getX(), player.getY(), player.getZ(), player.getYRot(), player.getXRot()));
        if (!data.isBuilt(instance)) {
            prepare(player, level);
            WAITING.put(player.getUUID(), instance);
            player.sendSystemMessage(Component.translatable("message.rifters.forming"), true);
            return;
        }
        enter(player, server, realm, data, instance);
    }

    private static void enter(ServerPlayer player, MinecraftServer server, ServerLevel realm, RiftersData data, int instance) {
        BlockPos c = centerOf(instance);
        double y = c.getY() + data.spawnHeight(instance);
        player.teleportTo(realm, c.getX() + 0.5, y, c.getZ() + 0.5, Set.of(), player.getYRot(), 0.0f, true);
        AdvancementHolder holder = server.getAdvancements().get(ADVANCEMENT);
        if (holder != null) player.getAdvancements().award(holder, "entered_rift");
    }

    private static void leave(ServerPlayer player, MinecraftServer server, RiftersData data, String id) {
        ReturnPoint rp = data.getReturn(id);
        ServerLevel target = null;
        double x, y, z;
        float yaw = player.getYRot(), pitch = 0.0f;
        if (rp != null) {
            try {
                target = server.getLevel(ResourceKey.create(Registries.DIMENSION, Identifier.parse(rp.dimension())));
            } catch (RuntimeException ignored) {
                target = null; // malformed id: fall back to the overworld spawn
            }
        }
        if (target == null || rp == null) {
            target = server.overworld();
            BlockPos spawn = target.getRespawnData().pos();
            x = spawn.getX() + 0.5; y = spawn.getY() + 1.0; z = spawn.getZ() + 0.5;
        } else {
            x = rp.x(); y = rp.y(); z = rp.z(); yaw = rp.yaw(); pitch = rp.pitch();
        }
        BlockPos bp = BlockPos.containing(x, y, z);
        for (int i = 0; i < 8; i++) { // lift out of anything that grew there in the meantime
            if (target.getBlockState(bp).getCollisionShape(target, bp).isEmpty()
                    && target.getBlockState(bp.above()).getCollisionShape(target, bp.above()).isEmpty()) break;
            bp = bp.above();
        }
        y = Math.max(y, bp.getY());
        player.teleportTo(target, x, y, z, Set.of(), yaw, pitch, true);
        data.clearReturn(id);
    }

    public static void tick(MinecraftServer server) {
        if (JOBS.isEmpty()) return;
        ServerLevel realm = server.getLevel(REALM);
        if (realm == null) { JOBS.clear(); return; }
        RiftersData data = RiftersData.get(server);
        Iterator<Job> it = JOBS.values().iterator();
        while (it.hasNext()) {
            Job job = it.next();
            if (!job.step(realm)) continue;
            it.remove();
            data.markBuilt(job.instance, job.plan.spawnY());
            Iterator<Map.Entry<UUID, Integer>> w = WAITING.entrySet().iterator();
            while (w.hasNext()) {
                Map.Entry<UUID, Integer> e = w.next();
                if (e.getValue() != job.instance) continue;
                w.remove();
                ServerPlayer p = server.getPlayerList().getPlayer(e.getKey());
                if (p != null && !p.level().dimension().equals(REALM)) enter(p, server, realm, data, job.instance);
            }
        }
    }

    public static void reset() {
        JOBS.clear();
        WAITING.clear();
    }
}
