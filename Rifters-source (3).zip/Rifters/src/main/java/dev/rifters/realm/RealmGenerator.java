package dev.rifters.realm;

import dev.rifters.registry.ModBlocks;
import dev.rifters.util.Noise3;
import dev.rifters.util.Rng;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * Builds the blueprint of one private cave, relative to its centre.
 * Shape: a noisy domed cavern with side chambers and rock pillars, wrapped in 4 layers of gloomstone
 * and then 2 layers of bedrock. Decorated with sculk, pale moss, veilblooms, amethyst and stalactites.
 */
final class RealmGenerator {
    static final int R = 37, YMIN = -27, YMAX = 33;
    private static final int SZ = 2 * R + 1, SY = YMAX - YMIN + 1;
    static final int GLOOM_LAYERS = 4, BEDROCK_LAYERS = 2;

    record Plan(LongArrayList positions, List<BlockState> states, int spawnY) {}

    private static int idx(int x, int y, int z) { return ((y - YMIN) * SZ + (z + R)) * SZ + (x + R); }

    private static boolean inBox(int x, int y, int z) {
        return x >= -R && x <= R && z >= -R && z <= R && y >= YMIN && y <= YMAX;
    }

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState BEDROCK = Blocks.BEDROCK.defaultBlockState();
    private static final BlockState SCULK = Blocks.SCULK.defaultBlockState();
    private static final BlockState MOSS = Blocks.PALE_MOSS_BLOCK.defaultBlockState();
    private static final BlockState DEEPSLATE = Blocks.DEEPSLATE.defaultBlockState();

    static Plan build(long seed) {
        final BlockState gloom = ModBlocks.GLOOMSTONE.defaultBlockState();
        final BlockState bloom = ModBlocks.VEILBLOOM.defaultBlockState();
        Noise3 noise = new Noise3(seed);
        int n = SZ * SZ * SY;
        boolean[] in = new boolean[n];

        // side chambers and pillars (deterministic from the seed)
        double[][] lobes = new double[5][4];
        for (int i = 0; i < 5; i++) {
            double a = (i + Rng.unit(seed, i, 0, 0, 101) * 0.8) * (Math.PI * 2 / 5);
            double dist = 15 + Rng.unit(seed, i, 1, 0, 102) * 4;
            lobes[i] = new double[]{Math.cos(a) * dist, -3 + Rng.unit(seed, i, 2, 0, 103) * 8, Math.sin(a) * dist,
                    8 + Rng.unit(seed, i, 3, 0, 104) * 3};
        }
        double[][] pillars = new double[6][3];
        for (int i = 0; i < 6; i++) {
            double a = Rng.unit(seed, i, 5, 0, 105) * Math.PI * 2;
            double dist = 12 + Rng.unit(seed, i, 6, 0, 106) * 9;
            pillars[i] = new double[]{Math.cos(a) * dist, Math.sin(a) * dist, 2.0 + Rng.unit(seed, i, 7, 0, 107) * 1.4};
        }

        for (int y = YMIN; y <= YMAX; y++) {
            for (int z = -R; z <= R; z++) {
                for (int x = -R; x <= R; x++) {
                    double v = y < 0 ? y / 11.0 : y / 20.0;
                    double nz = noise.fbm(x / 10.0, y / 9.0, z / 10.0);
                    boolean c = Math.sqrt((x * x + z * z) / 576.0 + v * v) + 0.24 * nz < 1.0;
                    if (!c) {
                        for (double[] l : lobes) {
                            double dx = x - l[0], dy = y - l[1], dz = z - l[2];
                            if (Math.sqrt(dx * dx + dy * dy + dz * dz) / l[3] + 0.22 * nz < 1.0) { c = true; break; }
                        }
                    }
                    if (c) {
                        for (double[] p : pillars) {
                            double rr = p[2] * (0.75 + 0.25 * Math.min(1.0, Math.abs(y + 2) / 10.0)) + 0.8 * nz;
                            if (Math.hypot(x - p[0], z - p[1]) < rr) { c = false; break; }
                        }
                    }
                    in[idx(x, y, z)] = c;
                }
            }
        }

        // distance (in blocks, 6-neighbourhood) from the cavity, up to the shell thickness
        byte[] dist = new byte[n];
        Arrays.fill(dist, (byte) -1);
        int[] queue = new int[n];
        int head = 0, tail = 0;
        for (int i = 0; i < n; i++) if (in[i]) { dist[i] = 0; queue[tail++] = i; }
        final int maxD = GLOOM_LAYERS + BEDROCK_LAYERS;
        final int[][] dirs = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
        while (head < tail) {
            int cur = queue[head++];
            int d = dist[cur];
            if (d >= maxD) continue;
            int x = cur % SZ - R, z = (cur / SZ) % SZ - R, y = cur / (SZ * SZ) + YMIN;
            for (int[] o : dirs) {
                int nx = x + o[0], ny = y + o[1], nzz = z + o[2];
                if (!inBox(nx, ny, nzz)) continue;
                int ni = idx(nx, ny, nzz);
                if (dist[ni] == -1) { dist[ni] = (byte) (d + 1); queue[tail++] = ni; }
            }
        }

        BlockState[] out = new BlockState[n];
        // ---- shell ----
        for (int y = YMIN; y <= YMAX; y++) for (int z = -R; z <= R; z++) for (int x = -R; x <= R; x++) {
            int i = idx(x, y, z);
            int d = dist[i];
            if (d <= 0) continue;
            if (d > GLOOM_LAYERS) { out[i] = BEDROCK; continue; }
            double r = Rng.unit(seed, x, y, z, 1);
            if (d == 1) {
                boolean floor = inBox(x, y + 1, z) && in[idx(x, y + 1, z)];
                if (floor) {
                    double na = noise.sample(x / 7.0, 0.5, z / 7.0);
                    out[i] = na > 0.02 ? SCULK : (na < -0.30 ? MOSS : (r < 0.08 ? DEEPSLATE : gloom));
                } else {
                    double nb = noise.fbm(x / 6.0 + 40, y / 6.0, z / 6.0);
                    out[i] = nb > 0.42 ? SCULK : (r < 0.10 ? DEEPSLATE : gloom);
                }
            } else {
                out[i] = r < 0.07 ? DEEPSLATE : (r < 0.10 ? SCULK : gloom);
            }
        }
        // ---- cavity: air by default (the dimension is natural stone underneath) ----
        for (int i = 0; i < n; i++) if (in[i]) out[i] = AIR;

        // ---- decoration ----
        for (int y = YMIN + 1; y < YMAX; y++) for (int z = -R; z <= R; z++) for (int x = -R; x <= R; x++) {
            int i = idx(x, y, z);
            if (!in[i] || x * x + z * z <= 36) continue;
            boolean floor = !in[idx(x, y - 1, z)];
            boolean ceil = !in[idx(x, y + 1, z)];
            double r = Rng.unit(seed, x, y, z, 2);
            if (floor && out[i] == AIR) {
                BlockState below = out[idx(x, y - 1, z)];
                if (below == SCULK) {
                    if (r < 0.22) out[i] = bloom;
                    else if (r < 0.235) out[i] = Blocks.SCULK_SENSOR.defaultBlockState();
                    else if (r < 0.241) out[i] = Blocks.SCULK_CATALYST.defaultBlockState();
                } else if (below == MOSS) {
                    if (r < 0.32) out[i] = Blocks.PALE_MOSS_CARPET.defaultBlockState();
                    else if (r < 0.40) out[i] = bloom;
                    else if (r < 0.42) out[i] = Blocks.CLOSED_EYEBLOSSOM.defaultBlockState();
                } else if (r < 0.045) {
                    out[i] = bloom;
                } else if (r < 0.06) {
                    spike(out, in, x, y, z, 1, 2 + (int) (Rng.unit(seed, x, y, z, 3) * 4), gloom);
                }
            } else if (ceil && out[i] == AIR) {
                if (r < 0.06) {
                    int len = 1 + (int) (Rng.unit(seed, x, y, z, 4) * 3);
                    for (int k = 0; k < len; k++) {
                        if (!inBox(x, y - k, z) || !in[idx(x, y - k, z)] || out[idx(x, y - k, z)] != AIR) break;
                        out[idx(x, y - k, z)] = Blocks.PALE_HANGING_MOSS.defaultBlockState();
                    }
                } else if (r < 0.085) {
                    spike(out, in, x, y, z, -1, 2 + (int) (Rng.unit(seed, x, y, z, 5) * 5), gloom);
                } else if (r < 0.097) {
                    out[i] = Blocks.AMETHYST_CLUSTER.defaultBlockState().setValue(BlockStateProperties.FACING, Direction.DOWN);
                }
            } else if (out[i] == AIR && r < 0.012) {
                for (Direction dir : Direction.Plane.HORIZONTAL) {
                    int wx = x + dir.getStepX(), wz = z + dir.getStepZ();
                    if (!in[idx(wx, y, wz)]) {
                        out[i] = Blocks.AMETHYST_CLUSTER.defaultBlockState().setValue(BlockStateProperties.FACING, dir.getOpposite());
                        break;
                    }
                }
            }
        }

        // ---- spawn platform ("rift sigil") at the centre ----
        int fy = YMIN + 1;
        for (int y = YMIN + 1; y < YMAX; y++) {
            if (in[idx(0, y, 0)] && !in[idx(0, y - 1, 0)]) { fy = y; break; }
        }
        for (int dz = -3; dz <= 3; dz++) for (int dx = -3; dx <= 3; dx++) {
            int r2 = dx * dx + dz * dz;
            if (r2 > 10) continue;
            BlockState floorBlock = r2 <= 1 ? Blocks.CRYING_OBSIDIAN.defaultBlockState()
                    : (r2 >= 5 && ((dx + dz) & 1) == 0 ? SCULK : Blocks.POLISHED_DEEPSLATE.defaultBlockState());
            out[idx(dx, fy - 1, dz)] = floorBlock;
            for (int dy = 0; dy <= 3; dy++) out[idx(dx, fy + dy, dz)] = AIR;
        }

        LongArrayList positions = new LongArrayList();
        List<BlockState> states = new ArrayList<>();
        for (int y = YMIN; y <= YMAX; y++) for (int z = -R; z <= R; z++) for (int x = -R; x <= R; x++) {
            BlockState s = out[idx(x, y, z)];
            if (s != null) { positions.add(BlockPos.asLong(x, y, z)); states.add(s); }
        }
        return new Plan(positions, states, fy);
    }

    /** Stalactite (dir=-1) or stalagmite (dir=+1) of gloomstone, tapering to a single block. */
    private static void spike(BlockState[] out, boolean[] in, int x, int y, int z, int dir, int len, BlockState gloom) {
        for (int k = 0; k < len; k++) {
            int yy = y + dir * k;
            if (!inBox(x, yy, z) || !in[idx(x, yy, z)]) break;
            out[idx(x, yy, z)] = gloom;
            if (k == 0) {
                for (int[] o : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
                    int sx = x + o[0], sz = z + o[1];
                    if (inBox(sx, yy, sz) && in[idx(sx, yy, sz)] && out[idx(sx, yy, sz)] == AIR) out[idx(sx, yy, sz)] = gloom;
                }
            }
        }
    }
}
