package dev.rifters.entity;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.vex.Vex;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * The guardian of the Rift Spire. A tall skeletal wraith that fights with its tail, its skull and the rift itself.
 * (It borrows the zombie AI for walking and biting; the look and all special attacks are its own.)
 *
 *  - Tail Sweep (close range): coils, then spins its tail through everything around it.
 *  - Rift Gaze  (long range):  rears its skull back, shows a warning line, then fires a piercing beam.
 *  - Rift Call  (below 50%):   levitates and opens its ribs to pull vexes out of the rift.
 *  - Rift Step  (below 25%):   folds into the rift, reappears behind its target and sweeps at once.
 */
public class RiftSovereign extends Zombie {
    public static final int NONE = 0, SWEEP = 1, GAZE = 2, CALL = 3, STEP = 4, WAKE = 5;
    /** The boss never walks further than this from the arena centre (the stair opening starts at 7 blocks). */
    private static final double ARENA_LIMIT = 6.6;
    private static final String HOME_TAG = "rifters_home:";

    private static final EntityDataAccessor<Integer> DATA_ATTACK =
            SynchedEntityData.defineId(RiftSovereign.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TICK =
            SynchedEntityData.defineId(RiftSovereign.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_DORMANT =
            SynchedEntityData.defineId(RiftSovereign.class, EntityDataSerializers.BOOLEAN);

    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.translatable("entity.rifters.rift_sovereign"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_10);
    private int cooldown = 80;
    private int attackTick;
    private Vec3 gazeDir = Vec3.ZERO;
    private BlockPos home;

    public RiftSovereign(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
        this.setBaby(false);
    }

    public static AttributeSupplier.Builder createBossAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 400.0)
                .add(Attributes.ATTACK_DAMAGE, 26.0)
                .add(Attributes.ARMOR, 4.0)
                .add(Attributes.ARMOR_TOUGHNESS, 0.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.MOVEMENT_SPEED, 0.27)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.SPAWN_REINFORCEMENTS_CHANCE, 0.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_ATTACK, NONE);
        builder.define(DATA_TICK, 0);
        builder.define(DATA_DORMANT, Boolean.TRUE);
    }

    public int getAttackType() { return this.entityData.get(DATA_ATTACK); }

    public int getAttackTick() { return this.entityData.get(DATA_TICK); }

    /** Standing motionless in its epic pose until somebody strikes it. */
    public boolean isDormant() { return this.entityData.get(DATA_DORMANT); }

    // ---- arena home (stored in the entity's tags so it survives reloads) ----
    public void setHome(BlockPos pos) {
        this.home = pos;
        for (String t : new java.util.ArrayList<>(getTags())) if (t.startsWith(HOME_TAG)) removeTag(t);
        addTag(HOME_TAG + pos.getX() + ":" + pos.getY() + ":" + pos.getZ());
    }

    private BlockPos readHome() {
        for (String tag : getTags()) {
            if (!tag.startsWith(HOME_TAG)) continue;
            try {
                String[] p = tag.substring(HOME_TAG.length()).split(":");
                return new BlockPos(Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2]));
            } catch (RuntimeException ignored) { /* malformed: fall through */ }
        }
        return null;
    }

    /** Keeps the boss on the arena floor: no walking out of the doors, no falling down the stair opening. */
    private void keepInArena() {
        if (home == null) home = readHome();
        if (home == null) { setHome(blockPosition()); return; }   // e.g. /summon: home is where it first stands
        double cx = home.getX() + 0.5, cz = home.getZ() + 0.5;
        double dx = getX() - cx, dz = getZ() - cz, d = Math.hypot(dx, dz);
        if (d > ARENA_LIMIT || getY() < home.getY() - 2.0) {
            double k = d > ARENA_LIMIT ? ARENA_LIMIT / d : 1.0;
            double y = getY() < home.getY() - 2.0 ? home.getY() : getY();
            setPos(cx + dx * k, y, cz + dz * k);
            Vec3 m = getDeltaMovement();
            setDeltaMovement(0.0, Math.min(m.y, 0.0), 0.0);
            getNavigation().stop();
        }
    }

    // ------------------------------------------------------------------ vanilla behaviour tweaks

    @Override protected boolean isSunSensitive() { return false; }

    @Override protected boolean convertsInWater() { return false; }

    @Override public boolean isBaby() { return false; }

    @Override public boolean removeWhenFarAway(double distanceSqr) { return false; }

    /**
     * Holds the boss in place. NOTE: this must not be done through isImmobile(): when that returns true the game skips
     * the whole AI step, including customServerAiStep(), and the attack state machine would never advance.
     */
    private void freeze() {
        getNavigation().stop();
        getMoveControl().setWantedPosition(getX(), getY(), getZ(), 0.0);
    }

    @Override
    public boolean isPushable() {
        return !isDormant() && super.isPushable();
    }

    /** A sleeping statue does not pick fights. */
    @Override
    public void setTarget(LivingEntity target) {
        super.setTarget(isDormant() ? null : target);
    }

    /** Hard cap on single-hit damage so nothing can one-shot the boss. */
    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        boolean hurt = super.hurtServer(level, source, Math.min(amount, 40.0f));
        if (hurt && isDormant() && isAlive()) wakeUp(level, source.getEntity());
        return hurt;
    }

    /** The first blow breaks the pose: the boss roars, shakes the arena and the fight begins. */
    private void wakeUp(ServerLevel level, net.minecraft.world.entity.Entity attacker) {
        this.entityData.set(DATA_DORMANT, Boolean.FALSE);
        bossEvent.setVisible(true);
        if (attacker instanceof Player player) setTarget(player);
        startAttack(WAKE, 0);
    }

    @Override protected SoundEvent getAmbientSound() { return isDormant() ? null : SoundEvents.WITHER_SKELETON_AMBIENT; }

    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.WITHER_SKELETON_HURT; }

    @Override protected SoundEvent getDeathSound() { return SoundEvents.WITHER_SKELETON_DEATH; }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    // ------------------------------------------------------------------ attack brain

    /**
     * All boss logic runs from tick(), which is guaranteed to run every tick (the vanilla customServerAiStep hook was
     * never reached for this entity, so the boss bar and the attacks never updated).
     * While dormant or in the middle of a special attack the boss is held in place: whatever the zombie AI tried to do
     * this tick is cancelled afterwards.
     */
    @Override
    public void tick() {
        final boolean hold = isDormant() || getAttackType() != NONE;
        final double px = getX(), pz = getZ();
        super.tick();
        if (!(level() instanceof ServerLevel serverLevel)) return;
        if (hold && isAlive()) {
            setPos(px, getY(), pz);
            Vec3 m = getDeltaMovement();
            setDeltaMovement(0.0, m.y, 0.0);
            getNavigation().stop();
        }
        if (isAlive()) serverLogic(serverLevel);
    }

    private static boolean loggedBrain;

    private Player findTarget(ServerLevel level) {
        if (getTarget() instanceof Player p && p.isAlive() && !p.isSpectator()) return p;
        Player best = null;
        double bestD = 40.0 * 40.0;
        for (ServerPlayer p : level.players()) {
            if (!p.isAlive() || p.isSpectator()) continue;
            double d = p.distanceToSqr(this);
            if (d < bestD) { bestD = d; best = p; }
        }
        return best;   // creative players are valid targets too (they just take no damage), handy for testing
    }

    private void serverLogic(ServerLevel level) {
        if (!loggedBrain) { loggedBrain = true; dev.rifters.Rifters.LOGGER.info("Rift Sovereign brain is running"); }
        keepInArena();
        float ratio = getHealth() / getMaxHealth();
        bossEvent.setProgress(ratio);
        if (isDormant()) {
            freeze();
            bossEvent.setVisible(false);
            // already wounded (e.g. the world was reloaded mid-fight): no more waiting
            if (getHealth() < getMaxHealth()) wakeUp(level, null);
            return;
        }

        Player target = findTarget(level);

        int type = getAttackType();
        if (type != NONE) {
            runAttack(level, type, target, ratio);
            return;
        }
        if (target == null) return;
        if (cooldown > 0) { cooldown--; return; }

        double d2 = distanceToSqr(target);
        int next;
        if (ratio < 0.25f && random.nextInt(4) == 0 && targetInArena(target)) next = STEP;
        else if (ratio < 0.5f && random.nextInt(4) == 0) next = CALL;
        else if (d2 < 10.0 * 10.0) next = SWEEP;
        else if (d2 < 28.0 * 28.0 && hasLineOfSight(target)) next = GAZE;
        else return;
        startAttack(next, 0);
    }

    private void startAttack(int type, int fromTick) {
        this.attackTick = fromTick;
        this.entityData.set(DATA_ATTACK, type);
        this.entityData.set(DATA_TICK, fromTick);
    }

    private void endAttack(float ratio) {
        this.attackTick = 0;
        this.entityData.set(DATA_ATTACK, NONE);
        this.entityData.set(DATA_TICK, 0);
        this.cooldown = ratio < 0.25f ? 30 : (ratio < 0.5f ? 50 : 70);
    }

    private void runAttack(ServerLevel level, int type, Player target, float ratio) {
        final int t = this.attackTick;
        freeze();
        if (target != null) getLookControl().setLookAt(target, 40.0f, 40.0f);

        switch (type) {
            case SWEEP -> {
                if (t == 0) level.playSound(null, blockPosition(), SoundEvents.WITHER_SHOOT, SoundSource.HOSTILE, 1.5f, 0.5f);
                if (t < 16 && t % 3 == 0) tailParticles(level, ParticleTypes.SCULK_SOUL, 3);
                if (t == 16) sweepHit(level);
                if (t >= 34) { endAttack(ratio); return; }
            }
            case GAZE -> {
                Vec3 origin = gazeOrigin();
                if (t == 0) level.playSound(null, blockPosition(), SoundEvents.WARDEN_SONIC_CHARGE, SoundSource.HOSTILE, 3.0f, 0.8f);
                if (t > 4 && t < 34 && t % 2 == 0) {
                    level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, origin.x, origin.y, origin.z, 2, 0.25, 0.25, 0.25, 0.01);
                }
                if (t == 26 && target != null) gazeDir = target.getEyePosition().subtract(origin).normalize();
                if (t >= 26 && t < 34 && t % 2 == 0 && gazeDir.lengthSqr() > 0.0) {   // warning line
                    for (double d = 3.0; d < 26.0; d += 2.0) {
                        Vec3 p = origin.add(gazeDir.scale(d));
                        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
                    }
                }
                if (t == 34) gazeFire(level, origin);
                if (t >= 52) { endAttack(ratio); return; }
            }
            case CALL -> {
                if (t == 0) level.playSound(null, blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, SoundSource.HOSTILE, 2.0f, 0.7f);
                if (t > 6 && t < 40 && t % 2 == 0) tailParticles(level, ParticleTypes.REVERSE_PORTAL, 6);
                if (t == 24) for (int i = 0; i < 3; i++) summonVex(level);
                if (t >= 46) { endAttack(ratio); return; }
            }
            case WAKE -> {
                if (t == 0) level.playSound(null, blockPosition(), SoundEvents.WARDEN_ROAR, SoundSource.HOSTILE, 4.0f, 0.7f);
                if (t == 14) wakeShockwave(level);
                if (t >= 36) { endAttack(ratio); this.cooldown = 40; return; }
            }
            case STEP -> {
                if (t < 12 && t % 2 == 0) {
                    level.sendParticles(ParticleTypes.REVERSE_PORTAL, getX(), getY() + 2.0, getZ(), 10, 0.5, 1.2, 0.5, 0.1);
                }
                if (t == 12 && target != null) riftStep(level, target);
                if (t >= 24) { startAttack(SWEEP, 8); return; }   // arrives with a shortened windup
            }
            default -> { endAttack(ratio); return; }
        }
        this.attackTick = t + 1;
        this.entityData.set(DATA_TICK, this.attackTick);
    }

    // ------------------------------------------------------------------ the attacks

    private List<Player> playersWithin(ServerLevel level, double radius) {
        return level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(radius, 3.0, radius),
                p -> p.isAlive() && !p.isSpectator() && !p.isCreative() && p.distanceToSqr(this) <= radius * radius);
    }

    private void tailParticles(ServerLevel level, net.minecraft.core.particles.SimpleParticleType type, int count) {
        double yaw = Math.toRadians(getYRot() + 90.0);   // behind the boss
        double x = getX() - Math.cos(yaw) * 1.6, z = getZ() - Math.sin(yaw) * 1.6;
        level.sendParticles(type, x, getY() + 2.0, z, count, 0.4, 0.8, 0.4, 0.02);
    }

    private void sweepHit(ServerLevel level) {
        level.playSound(null, blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 3.0f, 0.5f);
        for (int i = 0; i < 24; i++) {
            double a = i * Math.PI / 12.0;
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, getX() + Math.cos(a) * 5.0, getY() + 1.2, getZ() + Math.sin(a) * 5.0, 1, 0, 0, 0, 0);
            level.sendParticles(ParticleTypes.SCULK_SOUL, getX() + Math.cos(a) * 7.0, getY() + 0.3, getZ() + Math.sin(a) * 7.0, 1, 0.1, 0.05, 0.1, 0.02);
        }
        for (Player p : playersWithin(level, 8.0)) {
            p.hurtServer(level, level.damageSources().mobAttack(this), 18.0f);
            Vec3 away = p.position().subtract(position()).multiply(1, 0, 1).normalize().scale(1.5);
            p.push(away.x, 0.5, away.z);
            p.hurtMarked = true;
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 0));
        }
    }

    private Vec3 gazeOrigin() {
        return new Vec3(getX(), getY() + getBbHeight() * 0.84, getZ());
    }

    private void gazeFire(ServerLevel level, Vec3 origin) {
        if (gazeDir.lengthSqr() < 1.0e-4) return;
        level.playSound(null, blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.HOSTILE, 3.0f, 0.8f);
        final double range = 26.0;
        Vec3 end = origin.add(gazeDir.scale(range));
        for (double d = 1.0; d < range; d += 1.0) {
            Vec3 p = origin.add(gazeDir.scale(d));
            level.sendParticles(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
        for (Player p : level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(range), pl -> pl.isAlive() && !pl.isSpectator() && !pl.isCreative())) {
            if (distanceToSegment(p.getBoundingBox().getCenter(), origin, end) > 1.4) continue;
            p.hurtServer(level, level.damageSources().sonicBoom(this), 22.0f);
            p.push(gazeDir.x * 1.5, 0.3, gazeDir.z * 1.5);
            p.hurtMarked = true;
        }
    }

    private static double distanceToSegment(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = ab.lengthSqr();
        double u = len2 == 0.0 ? 0.0 : Math.max(0.0, Math.min(1.0, p.subtract(a).dot(ab) / len2));
        return p.distanceTo(a.add(ab.scale(u)));
    }

    private void summonVex(ServerLevel level) {
        Vex vex = EntityType.VEX.create(level, EntitySpawnReason.MOB_SUMMONED);
        if (vex == null) return;
        BlockPos pos = blockPosition().offset(random.nextInt(9) - 4, 2 + random.nextInt(3), random.nextInt(9) - 4);
        vex.snapTo(pos, 0.0f, 0.0f);
        vex.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), EntitySpawnReason.MOB_SUMMONED, null);
        vex.setOwner(this);
        vex.setBoundOrigin(pos);
        vex.setLimitedLife(20 * 30);
        level.addFreshEntity(vex);
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 12, 0.3, 0.3, 0.3, 0.1);
    }

    private boolean targetInArena(Player target) {
        if (home == null || target == null) return false;
        return Math.hypot(target.getX() - (home.getX() + 0.5), target.getZ() - (home.getZ() + 0.5)) < 9.0;
    }

    private void wakeShockwave(ServerLevel level) {
        level.playSound(null, blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.HOSTILE, 3.0f, 0.5f);
        for (int i = 0; i < 24; i++) {
            double a = i * Math.PI / 12.0;
            level.sendParticles(ParticleTypes.SCULK_SOUL, getX() + Math.cos(a) * 3.0, getY() + 0.3, getZ() + Math.sin(a) * 3.0, 2, 0.1, 0.1, 0.1, 0.05);
        }
        for (Player p : playersWithin(level, 7.0)) {
            Vec3 away = p.position().subtract(position()).multiply(1, 0, 1).normalize().scale(1.2);
            p.push(away.x, 0.5, away.z);
            p.hurtMarked = true;
        }
    }

    private void riftStep(ServerLevel level, Player target) {
        Vec3 look = target.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0.0, look.z);
        flat = flat.lengthSqr() < 1.0e-4 ? new Vec3(0.0, 0.0, 1.0) : flat.normalize();
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, getX(), getY() + 2.0, getZ(), 30, 0.6, 1.5, 0.6, 0.2);
        double tx = target.getX() - flat.x * 3.4, tz = target.getZ() - flat.z * 3.4;
        if (home != null) {   // never step out of the arena
            double cx = home.getX() + 0.5, cz = home.getZ() + 0.5, d = Math.hypot(tx - cx, tz - cz);
            if (d > ARENA_LIMIT) { tx = cx + (tx - cx) * ARENA_LIMIT / d; tz = cz + (tz - cz) * ARENA_LIMIT / d; }
        }
        randomTeleport(tx, home != null ? home.getY() : target.getY(), tz, true);
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, getX(), getY() + 2.0, getZ(), 30, 0.6, 1.5, 0.6, 0.2);
        level.playSound(null, blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 2.0f, 0.5f);
        getLookControl().setLookAt(target, 360.0f, 360.0f);
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level() instanceof ServerLevel serverLevel) {
            for (ServerPlayer player : serverLevel.players()) {
                if (player.distanceToSqr(this) < 96.0 * 96.0) {
                    player.sendSystemMessage(Component.translatable("message.rifters.sovereign_defeated"), false);
                }
            }
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        bossEvent.removeAllPlayers();
        super.remove(reason);
    }
}
