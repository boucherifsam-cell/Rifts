package dev.rifters.tower;

import dev.rifters.util.Rng;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Procedural blueprint of the Rift Spire, expressed relative to the tower axis.
 * y = 0 is the walking level of the ground floor; the axis is block (0, 0).
 *
 * Layout (all dimensions in blocks):
 *  - round drum, outer radius 14 -> 13 -> 12 with weathered setbacks, 2 thick walls, 12 pilasters, 8 buttresses
 *  - hollow atrium with a 3-wide spiral staircase (2 turns, 66 blocks of rise) hugging the wall,
 *    a landing niche with a loot chest every 11 blocks, tinted-glass arrow slits
 *  - boss arena (floor at y = 66): radius 10, 8 pillars, 8 arched doors onto a battlemented balcony, sigil floor
 *  - gothic cone roof topped with amethyst and a lightning rod
 *  - entrance arch + ramp on the south side, foundations that follow the terrain
 */
public final class TowerBlueprint {
    public static final int ARENA_Y = 66;
    private static final double TAU = Math.PI * 2;
    private static final double H_RAD = 33.0 / TAU; // stair rise per radian (33 blocks per turn)
    private static final int WALL_TOP = 77;

    public static final byte NORMAL = 0, FIX = 1, CHEST = 2;

    public record Entry(int x, int y, int z, BlockState state, byte kind) {}
    public record Anchor(int x, int z, int top, BlockState state) {}

    public static final class Part {
        public final List<Entry> entries = new ArrayList<>();
        public final List<Anchor> anchors = new ArrayList<>();
    }

    /** All parts keyed by chunk offset from the tower's centre chunk. */
    public static final class Plan {
        public final Map<Long, Part> parts = new HashMap<>();
        public Part part(int dx, int dz) { return parts.get(pack(dx, dz)); }
    }

    public static long pack(int dx, int dz) { return ((long) dx << 32) | (dz & 0xFFFFFFFFL); }

    // ------------------------------------------------------------------

    private final long seed;
    private final Map<Long, BlockState> cells = new HashMap<>(1 << 16);
    private final Map<Long, Byte> kinds = new HashMap<>();
    private final List<Anchor> anchors = new ArrayList<>();

    private TowerBlueprint(long seed) { this.seed = seed; }

    public static Plan generate(long seed) {
        TowerBlueprint b = new TowerBlueprint(seed);
        b.build();
        return b.toPlan();
    }

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState STONE_BRICKS = Blocks.STONE_BRICKS.defaultBlockState();
    private static final BlockState MOSSY = Blocks.MOSSY_STONE_BRICKS.defaultBlockState();
    private static final BlockState CRACKED = Blocks.CRACKED_STONE_BRICKS.defaultBlockState();
    private static final BlockState DS_BRICKS = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
    private static final BlockState DS_CRACKED = Blocks.CRACKED_DEEPSLATE_BRICKS.defaultBlockState();
    private static final BlockState DS_TILES = Blocks.DEEPSLATE_TILES.defaultBlockState();
    private static final BlockState DS_POLISHED = Blocks.POLISHED_DEEPSLATE.defaultBlockState();
    private static final BlockState DS_COBBLED = Blocks.COBBLED_DEEPSLATE.defaultBlockState();
    private static final BlockState PALE_LOG = Blocks.PALE_OAK_LOG.defaultBlockState();
    private static final BlockState PALE_PLANKS = Blocks.PALE_OAK_PLANKS.defaultBlockState();
    private static final BlockState PALE_FENCE = Blocks.PALE_OAK_FENCE.defaultBlockState();
    private static final BlockState PALE_MOSS = Blocks.PALE_MOSS_BLOCK.defaultBlockState();
    private static final BlockState RESIN = Blocks.RESIN_BRICKS.defaultBlockState();
    private static final BlockState RESIN_CHISELED = Blocks.CHISELED_RESIN_BRICKS.defaultBlockState();
    private static final BlockState SLAB = Blocks.STONE_BRICK_SLAB.defaultBlockState();
    private static final BlockState TINTED = Blocks.TINTED_GLASS.defaultBlockState();
    private static final BlockState LANTERN = Blocks.SOUL_LANTERN.defaultBlockState();
    private static final BlockState SCULK = Blocks.SCULK.defaultBlockState();
    private static final BlockState AMETHYST = Blocks.AMETHYST_BLOCK.defaultBlockState();
    private static final BlockState CRYING = Blocks.CRYING_OBSIDIAN.defaultBlockState();

    private static int outerR(int y) { return y <= 16 ? 14 : (y <= 36 ? 13 : 12); }
    private static double rad(int x, int z) { return Math.sqrt((double) x * x + (double) z * z); }
    private static double ang(int x, int z) { double a = Math.atan2(z, x); return a < 0 ? a + TAU : a; }
    private static double angDist(double a, double b) {
        double d = Math.abs(a - b) % TAU;
        return d > Math.PI ? TAU - d : d;
    }
    private double u(int x, int y, int z, int salt) { return Rng.unit(seed, x, y, z, salt); }

    private void set(int x, int y, int z, BlockState s) {
        long k = BlockPos.asLong(x, y, z);
        cells.put(k, s);
        kinds.remove(k);
    }
    private void set(int x, int y, int z, BlockState s, byte kind) {
        long k = BlockPos.asLong(x, y, z);
        cells.put(k, s);
        if (kind == NORMAL) kinds.remove(k); else kinds.put(k, kind);
    }

    private BlockState wall(int x, int y, int z) {
        double r = u(x, y, z, 3);
        if (y < 18) {
            if (r < 0.06) return PALE_MOSS;
            if (r < 0.30) return MOSSY;
            if (r < 0.42) return CRACKED;
            return STONE_BRICKS;
        }
        if (y < 40) return r < 0.15 ? CRACKED : (r < 0.40 ? DS_BRICKS : STONE_BRICKS);
        if (y <= 65) return r < 0.15 ? DS_CRACKED : (r < 0.35 ? DS_TILES : DS_BRICKS);
        return r < 0.15 ? DS_POLISHED : (r < 0.30 ? DS_BRICKS : DS_TILES);
    }

    private BlockState footing(int x, int z) {
        double r = u(x, 0, z, 4);
        return r < 0.4 ? DS_COBBLED : (r < 0.7 ? STONE_BRICKS : (r < 0.85 ? MOSSY : DS_BRICKS));
    }

    // ------------------------------------------------------------------
    private void build() {
        final int E = 24;

        // 1. floor, interior volume and walls
        for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
            double r = rad(x, z);
            if (r < 14) set(x, -1, z, groundFloor(x, z, r));
            for (int y = 0; y <= WALL_TOP; y++) {
                int ro = outerR(y);
                if (r < ro - 2) set(x, y, z, AIR);
                else if (r < ro) set(x, y, z, wall(x, y, z));
            }
        }

        // 2. weathered ledges at the setbacks, resin bands and a cornice
        for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
            double r = rad(x, z);
            if (r >= 13 && r < 14) set(x, 17, z, SLAB);
            if (r >= 12 && r < 13) set(x, 37, z, SLAB);
            if (r >= 14 && r < 15) set(x, 16, z, RESIN);
            if (r >= 13 && r < 14) set(x, 36, z, RESIN);
        }

        // 3. pilasters (12), full height
        for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
            double r = rad(x, z), a = ang(x, z);
            double best = 9;
            for (int k = 0; k < 12; k++) best = Math.min(best, angDist(a, Math.toRadians(15 + 30 * k)) * r);
            if (best > 0.85) continue;
            for (int y = 0; y <= WALL_TOP; y++) {
                int ro = outerR(y);
                if (r >= ro && r < ro + 1) set(x, y, z, y == WALL_TOP ? RESIN_CHISELED : PALE_LOG);
            }
        }

        // 4. buttresses (8) with stepped profile
        for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
            double r = rad(x, z), a = ang(x, z);
            double best = 9;
            for (int k = 0; k < 8; k++) best = Math.min(best, angDist(a, Math.toRadians(22.5 + 45 * k)) * r);
            if (best > 1.6) continue;
            for (int y = 0; y <= 22; y++) {
                int ro = outerR(y);
                int d = y <= 8 ? 3 : (y <= 15 ? 2 : 1);
                if (r >= ro && r < ro + d) set(x, y, z, u(x, y, z, 5) < 0.2 ? CRACKED : STONE_BRICKS);
            }
            int ro = outerR(23);
            if (r >= ro && r < ro + 1) set(x, 23, z, SLAB);
        }

        // 5. arrow slits (tinted glass), rotated every floor
        for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
            double r = rad(x, z), a = ang(x, z);
            for (int f = 0; f <= 5; f++) {
                int yw = 11 * f;
                int ro = outerR(yw + 3);
                if (r < ro - 2 || r >= ro) continue;
                for (int j = 0; j < 6; j++) {
                    double sa = Math.toRadians(60 * j + 20 * f + 5);
                    if (angDist(a, sa) * r <= 0.6) for (int y = yw + 2; y <= yw + 4; y++) set(x, y, z, TINTED);
                }
            }
        }

        // 6. landing niches with loot chests
        for (int f = 1; f <= 5; f++) {
            int yw = 11 * f;
            double a = (yw / H_RAD) % TAU;
            int rin = outerR(yw) - 2;
            for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
                double r = rad(x, z);
                if (r >= rin && r < rin + 1 && angDist(ang(x, z), a) * r <= 1.3)
                    for (int y = yw; y <= yw + 2; y++) set(x, y, z, AIR);
            }
            int cx = (int) Math.round((rin + 0.5) * Math.cos(a)), cz = (int) Math.round((rin + 0.5) * Math.sin(a));
            Direction facing = Math.abs(Math.cos(a)) >= Math.abs(Math.sin(a))
                    ? (-Math.cos(a) > 0 ? Direction.EAST : Direction.WEST)
                    : (-Math.sin(a) > 0 ? Direction.SOUTH : Direction.NORTH);
            set(cx, yw + 1, cz, AIR);
            set(cx, yw + 2, cz, AIR);
            set(cx, yw, cz, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, facing), CHEST);
        }

        // 7. spiral staircase: each (x,z) column gets one step per turn
        for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
            double r = rad(x, z), a = ang(x, z);
            for (int n = 0; n <= 1; n++) {
                int w = (int) Math.floor((a + TAU * n) * H_RAD);
                if (w > 65) continue;
                int rinW = outerR(w) - 2, rinPrev = outerR(Math.max(0, w - 1)) - 2;
                if (r >= rinW - 3 && r < Math.max(rinW, rinPrev)) {
                    set(x, w - 1, z, PALE_PLANKS);
                    if (r < rinW - 2 && w >= 1 && w < 62) {
                        set(x, w, z, PALE_FENCE, FIX);
                        if (u(x, w, z, 9) < 0.08) set(x, w + 1, z, LANTERN);
                    }
                }
            }
        }

        // 8. arena floor with sigil (an opening is left above the last flight of stairs)
        for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
            double r = rad(x, z), a = ang(x, z);
            if (r >= 10) continue;
            if (r >= 7 && a >= 5.33) continue;
            set(x, ARENA_Y - 1, z, arenaFloor(x, z, r, a));
        }

        // 9. arena: pillars, arched doors, lanterns
        for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
            double r = rad(x, z), a = ang(x, z);
            double pil = 9;
            for (int k = 0; k < 8; k++) pil = Math.min(pil, angDist(a, Math.toRadians(22.5 + 45 * k)) * r);
            if (r >= 8.6 && r < 10 && pil <= 0.9)
                for (int y = ARENA_Y; y <= WALL_TOP - 1; y++) set(x, y, z, PALE_LOG);
            if (r >= 8.6 && r < 10 && pil <= 0.9) set(x, WALL_TOP, z, RESIN_CHISELED);
            double door = 9;
            for (int k = 0; k < 8; k++) door = Math.min(door, angDist(a, Math.toRadians(45 * k)) * r);
            if (r >= 10 && r < 12.6) for (int t = 0; t <= 8; t++) {
                double half = t <= 4 ? 1.5 : Math.max(0.0, 1.5 - (t - 4) * 0.4);
                if (door <= half) set(x, ARENA_Y + t, z, AIR);
            }
        }
        for (int k = 0; k < 8; k++) {
            double a = Math.toRadians(45 * k);
            set((int) Math.round(7.5 * Math.cos(a)), ARENA_Y, (int) Math.round(7.5 * Math.sin(a)), LANTERN);
        }

        // 10. balcony: corbels, deck, battlements
        for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
            double r = rad(x, z), a = ang(x, z);
            for (int y = 60; y <= 64; y++) if (r >= 12 && r <= 12 + (y - 59) * 0.45) set(x, y, z, y == 64 ? STONE_BRICKS : DS_BRICKS);
            if (r >= 12 && r <= 14.2) set(x, 65, z, STONE_BRICKS);
            if (r >= 13.2 && r <= 14.2) {
                set(x, 66, z, DS_BRICKS);
                if (((int) (a / TAU * 30)) % 2 == 0) set(x, 67, z, DS_BRICKS);
            }
        }

        // 11. cornice and gothic cone roof
        for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
            double r = rad(x, z);
            if (r >= 10 && r < 13.2) set(x, 78, z, r >= 12 ? SLAB : DS_BRICKS);
        }
        for (int y = 79; y <= 96; y++) {
            double t = (y - 79) / 18.0;
            double rc = 12.5 * Math.pow(1 - t, 1.2);
            for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
                double r = rad(x, z);
                if (r > rc || (y < 94 && r <= rc - 1.8)) continue;
                BlockState s = y >= 93 ? AMETHYST : (y % 5 == 0 ? RESIN : DS_TILES);
                set(x, y, z, s);
            }
        }
        set(0, 97, 0, Blocks.LIGHTNING_ROD.defaultBlockState());
        for (int k = 0; k < 8; k++) {
            double a = Math.toRadians(22.5 + 45 * k);
            int px = (int) Math.round(12.2 * Math.cos(a)), pz = (int) Math.round(12.2 * Math.sin(a));
            for (int y = 79; y <= 82; y++) set(px, y, pz, DS_POLISHED);
            set(px, 83, pz, AMETHYST);
        }

        // 12. entrance arch on the south side + ramp
        for (int z = 6; z <= 23; z++) for (int x = -3; x <= 3; x++) {
            boolean wallZone = z >= 12 && z < 14;
            for (int y = 0; y <= 6; y++) {
                int ax = Math.abs(x);
                boolean open = ax <= 2 && (y <= 4 || (y == 5 && ax <= 1) || (y == 6 && ax == 0));
                if (open) set(x, y, z, AIR);
                else if (wallZone && ax == 3) set(x, y, z, PALE_LOG);
                else if (wallZone && ((y == 5 && ax == 2) || (y == 6 && ax == 1) || (y == 7 && ax == 0))) set(x, y, z, RESIN);
            }
            if (wallZone && Math.abs(x) <= 0) set(x, 7, z, RESIN);
        }
        for (int z = 14; z <= 23; z++) for (int x = -2; x <= 2; x++) {
            int top = z <= 17 ? -1 : -1 - ((z - 16) / 2);
            if (z > 17) {
                set(x, top, z, u(x, top, z, 6) < 0.25 ? MOSSY : STONE_BRICKS);
                anchors.add(new Anchor(x, z, top - 1, footing(x, z)));
            }
            for (int y = top + 1; y <= top + 7; y++) set(x, y, z, AIR);
        }

        // 13. foundations / skirt following the terrain
        for (int z = -E; z <= E; z++) for (int x = -E; x <= E; x++) {
            double r = rad(x, z);
            if (r < 14) anchors.add(new Anchor(x, z, -2, footing(x, z)));
            else if (r < 17.5 && !cells.containsKey(BlockPos.asLong(x, -1, z))) {
                anchors.add(new Anchor(x, z, -1, footing(x, z)));
            }
        }
    }

    private BlockState groundFloor(int x, int z, double r) {
        if (r >= 12) return STONE_BRICKS;
        if (r <= 2.0) return AMETHYST;
        if (r >= 5.5 && r < 6.5) return SCULK;
        if (r >= 10.5 && r < 11.5) return CRYING;
        return ((x + z) & 1) == 0 ? DS_POLISHED : DS_TILES;
    }

    private BlockState arenaFloor(int x, int z, double r, double a) {
        if (r < 2.5) return CRYING;
        double spoke = 9;
        for (int k = 0; k < 8; k++) spoke = Math.min(spoke, angDist(a, Math.toRadians(45 * k)) * r);
        if (r < 9 && spoke <= 0.6) return AMETHYST;
        if (r >= 4.5 && r < 5.5) return SCULK;
        if (r >= 8 && r < 9) return CRYING;
        return ((x + z) & 1) == 0 ? DS_POLISHED : DS_TILES;
    }

    // ------------------------------------------------------------------
    private Plan toPlan() {
        Plan plan = new Plan();
        for (Map.Entry<Long, BlockState> e : cells.entrySet()) {
            BlockPos p = BlockPos.of(e.getKey());
            Byte k = kinds.get(e.getKey());
            plan.parts.computeIfAbsent(pack(Math.floorDiv(p.getX() + 8, 16), Math.floorDiv(p.getZ() + 8, 16)), x -> new Part())
                    .entries.add(new Entry(p.getX(), p.getY(), p.getZ(), e.getValue(), k == null ? NORMAL : k));
        }
        for (Anchor an : anchors) {
            plan.parts.computeIfAbsent(pack(Math.floorDiv(an.x() + 8, 16), Math.floorDiv(an.z() + 8, 16)), x -> new Part())
                    .anchors.add(an);
        }
        Comparator<Entry> byY = Comparator.comparingInt(Entry::y);
        for (Part part : plan.parts.values()) part.entries.sort(byY);
        return plan;
    }
}
