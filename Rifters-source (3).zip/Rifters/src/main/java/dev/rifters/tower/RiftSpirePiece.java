package dev.rifters.tower;

import dev.rifters.Rifters;
import dev.rifters.registry.ModEntities;
import dev.rifters.registry.ModStructures;
import dev.rifters.entity.RiftSovereign;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;
import net.minecraft.world.level.storage.loot.LootTable;

/** One big piece covering the whole tower; postProcess is called once per chunk and places that chunk's slice. */
public final class RiftSpirePiece extends StructurePiece {
    private static final ResourceKey<LootTable> CHEST_LOOT =
            ResourceKey.create(Registries.LOOT_TABLE, Rifters.id("chests/rift_spire"));
    private static final Map<Long, TowerBlueprint.Plan> PLANS = new ConcurrentHashMap<>();

    private final int originX, originY, originZ;
    private final long seed;

    public RiftSpirePiece(int originX, int originY, int originZ, long seed) {
        super(ModStructures.RIFT_SPIRE_PIECE, 0,
                new BoundingBox(originX - 24, originY - 41, originZ - 24, originX + 24, originY + 100, originZ + 24));
        this.originX = originX; this.originY = originY; this.originZ = originZ; this.seed = seed;
    }

    public RiftSpirePiece(CompoundTag tag) {
        super(ModStructures.RIFT_SPIRE_PIECE, tag);
        this.originX = tag.getIntOr("ox", 0);
        this.originY = tag.getIntOr("oy", 0);
        this.originZ = tag.getIntOr("oz", 0);
        this.seed = tag.getLongOr("seed", 0L);
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        tag.putInt("ox", originX);
        tag.putInt("oy", originY);
        tag.putInt("oz", originZ);
        tag.putLong("seed", seed);
    }

    @Override
    public void postProcess(WorldGenLevel level, StructureManager structures, ChunkGenerator generator,
                            RandomSource random, BoundingBox box, ChunkPos chunkPos, BlockPos pivot) {
        TowerBlueprint.Plan plan = PLANS.computeIfAbsent(seed, TowerBlueprint::generate);
        int dx = chunkPos.x() - Math.floorDiv(originX, 16), dz = chunkPos.z() - Math.floorDiv(originZ, 16);
        TowerBlueprint.Part part = plan.part(dx, dz);
        if (part == null) return;

        // 1. foundations: columns that follow the terrain down to solid ground
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (TowerBlueprint.Anchor a : part.anchors) {
            for (int d = 0; d < 40; d++) {
                m.set(originX + a.x(), originY + a.top() - d, originZ + a.z());
                if (level.isOutsideBuildHeight(m) || !box.isInside(m)) break;
                BlockState cur = level.getBlockState(m);
                boolean ground = !cur.isAir() && !cur.canBeReplaced() && cur.getFluidState().isEmpty()
                        && !cur.is(BlockTags.LEAVES) && !cur.is(BlockTags.LOGS);
                if (ground) break;
                level.setBlock(m, a.state(), 2 | 16);
            }
        }
        // 2. the blocks, bottom to top
        for (TowerBlueprint.Entry e : part.entries) {
            BlockPos pos = new BlockPos(originX + e.x(), originY + e.y(), originZ + e.z());
            if (level.isOutsideBuildHeight(pos) || !box.isInside(pos)) continue;
            level.setBlock(pos, e.state(), 2 | 16);
            if (e.kind() == TowerBlueprint.CHEST) RandomizableContainer.setBlockEntityLootTable(level, random, pos, CHEST_LOOT);
        }
        // 3. connect fences to their neighbours
        for (TowerBlueprint.Entry e : part.entries) {
            if (e.kind() != TowerBlueprint.FIX) continue;
            BlockPos pos = new BlockPos(originX + e.x(), originY + e.y(), originZ + e.z());
            if (!box.isInside(pos)) continue;
            BlockState cur = level.getBlockState(pos);
            BlockState upd = Block.updateFromNeighbourShapes(cur, level, pos);
            if (upd != cur) level.setBlock(pos, upd, 2 | 16);
        }
        // 4. the guardian waits in the arena (spawned with the chunk that holds the tower axis)
        if (dx == 0 && dz == 0) {
            RiftSovereign boss = ModEntities.RIFT_SOVEREIGN.create(level.getLevel(), EntitySpawnReason.STRUCTURE);
            if (boss != null) {
                BlockPos arena = new BlockPos(originX, originY + TowerBlueprint.ARENA_Y, originZ);
                boss.snapTo(arena, 0.0f, 0.0f);
                boss.setHome(arena);
                boss.setPersistenceRequired();
                level.addFreshEntityWithPassengers(boss);
            }
        }
    }
}
