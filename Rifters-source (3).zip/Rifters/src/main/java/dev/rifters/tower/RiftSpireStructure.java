package dev.rifters.tower;

import com.mojang.serialization.MapCodec;
import dev.rifters.registry.ModStructures;
import dev.rifters.util.Rng;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

/**
 * The Rift Spire as a real worldgen structure: it shows up in /locate and /place, is saved with the chunks,
 * and is built piece-by-piece while the terrain generates (no neighbour chunk is ever forced early).
 * Only starts where (nearly) the whole footprint is inside the biomes of the #rifters:has_rift_spire tag.
 */
public final class RiftSpireStructure extends Structure {
    public static final MapCodec<RiftSpireStructure> CODEC = simpleCodec(RiftSpireStructure::new);

    public RiftSpireStructure(Structure.StructureSettings settings) {
        super(settings);
    }

    @Override
    protected Optional<GenerationStub> findGenerationPoint(GenerationContext context) {
        ChunkPos chunk = context.chunkPos();
        int ox = chunk.getMiddleBlockX(), oz = chunk.getMiddleBlockZ();

        int hits = 0, maxHeight = Integer.MIN_VALUE;
        for (int i = 0; i < 9; i++) {
            int px = ox, pz = oz;
            if (i > 0) {
                double a = (i - 1) * Math.PI / 4;
                px += (int) Math.round(Math.cos(a) * 12);
                pz += (int) Math.round(Math.sin(a) * 12);
            }
            int h = context.chunkGenerator().getBaseHeight(px, pz, Heightmap.Types.WORLD_SURFACE_WG,
                    context.heightAccessor(), context.randomState());
            maxHeight = Math.max(maxHeight, h);
            // sample the biome AT the surface (below it the generator would answer with cave biomes)
            Holder<Biome> biome = context.biomeSource().getNoiseBiome(px >> 2, h >> 2, pz >> 2, context.randomState().sampler());
            if (context.validBiome().test(biome)) hits++;
        }
        if (hits < 7) return Optional.empty();

        final int originY = maxHeight; // first free block above the highest ground = tower walking level
        final long seed = Rng.mix(context.seed() ^ ((long) chunk.x() << 32) ^ (chunk.z() & 0xFFFFFFFFL));
        return Optional.of(new GenerationStub(new BlockPos(ox, originY, oz),
                builder -> builder.addPiece(new RiftSpirePiece(ox, originY, oz, seed))));
    }

    @Override
    public StructureType<?> type() {
        return ModStructures.RIFT_SPIRE;
    }
}
