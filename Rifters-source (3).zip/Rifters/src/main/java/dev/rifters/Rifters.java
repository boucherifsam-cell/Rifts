package dev.rifters;

import dev.rifters.entity.RiftSovereign;
import dev.rifters.realm.RealmManager;
import dev.rifters.registry.ModBlocks;
import dev.rifters.registry.ModEntities;
import dev.rifters.registry.ModItems;
import dev.rifters.registry.ModStructures;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.CreativeModeTabs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Rifters implements ModInitializer {
    public static final String MOD_ID = "rifters";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModItems.init();
        ModEntities.init();
        ModStructures.init();

        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(out -> out.accept(ModItems.RIFT_OPENER));
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.NATURAL_BLOCKS).register(out -> {
            out.accept(ModBlocks.GLOOMSTONE);
            out.accept(ModBlocks.VEILBLOOM);
        });

        ServerTickEvents.END_SERVER_TICK.register(RealmManager::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            RealmManager.reset();
        });
        LOGGER.info("Rifters loaded ({})", RiftSovereign.class.getSimpleName());
    }
}
