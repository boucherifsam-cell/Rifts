package dev.rifters.registry;

import dev.rifters.Rifters;
import dev.rifters.block.VeilbloomBlock;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.PushReaction;

public final class ModBlocks {
    private ModBlocks() {}

    /** The dark, violet-veined stone the rift realm is made of. */
    public static final Block GLOOMSTONE = register("gloomstone",
            p -> new Block(p.strength(3.0f, 9.0f).sound(SoundType.DEEPSLATE).requiresCorrectToolForDrops()));

    /** A softly glowing ghost flower that grows on sculk and pale moss. */
    public static final Block VEILBLOOM = register("veilbloom",
            p -> new VeilbloomBlock(p.noCollision().noOcclusion().instabreak().sound(SoundType.GRASS)
                    .lightLevel(state -> 7).pushReaction(PushReaction.DESTROY)));

    private static Block register(String name, Function<BlockBehaviour.Properties, Block> factory) {
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, Rifters.id(name));
        Block block = factory.apply(BlockBehaviour.Properties.of().setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, Rifters.id(name), block);
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, Rifters.id(name));
        Registry.register(BuiltInRegistries.ITEM, Rifters.id(name), new BlockItem(block, new Item.Properties().setId(itemKey)));
        return block;
    }

    public static void init() {}
}
