package dev.rifters.registry;

import dev.rifters.Rifters;
import dev.rifters.entity.RiftSovereign;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
    private ModEntities() {}

    public static final EntityType<RiftSovereign> RIFT_SOVEREIGN = register();

    private static EntityType<RiftSovereign> register() {
        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, Rifters.id("rift_sovereign"));
        EntityType<RiftSovereign> type = EntityType.Builder.<RiftSovereign>of(RiftSovereign::new, MobCategory.MONSTER)
                .sized(1.4f, 4.6f)
                .fireImmune()
                .clientTrackingRange(10)
                .build(key);
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, Rifters.id("rift_sovereign"), type);
    }

    public static void init() {
        FabricDefaultAttributeRegistry.register(RIFT_SOVEREIGN, RiftSovereign.createBossAttributes());
    }
}
