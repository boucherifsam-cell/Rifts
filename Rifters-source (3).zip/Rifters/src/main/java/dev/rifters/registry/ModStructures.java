package dev.rifters.registry;

import dev.rifters.Rifters;
import dev.rifters.tower.RiftSpirePiece;
import dev.rifters.tower.RiftSpireStructure;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;

public final class ModStructures {
    private ModStructures() {}

    private static final StructureType<RiftSpireStructure> STRUCTURE_TYPE = () -> RiftSpireStructure.CODEC;
    public static final StructureType<RiftSpireStructure> RIFT_SPIRE =
            Registry.register(BuiltInRegistries.STRUCTURE_TYPE, Rifters.id("rift_spire"), STRUCTURE_TYPE);

    private static final StructurePieceType.ContextlessType PIECE_TYPE = RiftSpirePiece::new;
    public static final StructurePieceType RIFT_SPIRE_PIECE =
            Registry.register(BuiltInRegistries.STRUCTURE_PIECE, Rifters.id("rift_spire"), PIECE_TYPE);

    public static void init() {}
}
