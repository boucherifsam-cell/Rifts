package dev.rifters.registry;

import dev.rifters.Rifters;
import dev.rifters.item.RiftOpenerItem;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

public final class ModItems {
    private ModItems() {}

    public static final Item RIFT_OPENER = register("rift_opener");

    private static Item register(String name) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Rifters.id(name));
        Item item = new RiftOpenerItem(new Item.Properties().setId(key).stacksTo(1).rarity(Rarity.EPIC));
        return Registry.register(BuiltInRegistries.ITEM, Rifters.id(name), item);
    }

    public static void init() {}
}
