import math, random
from PIL import Image
R='/home/claude/Rifters/src/main/resources/assets/rifters/textures/'
def mix(*a):
    h=0x9E3779B97F4A7C15
    for v in a:
        h^=(v&0xFFFFFFFFFFFFFFFF); h=(h*0xBF58476D1CE4E5B9)&0xFFFFFFFFFFFFFFFF; h^=h>>29
    return h
def u(*a): return (mix(*a)>>11)/float(1<<53)
def vnoise(x,y,per,seed):
    # tileable value noise
    x0=int(math.floor(x));y0=int(math.floor(y));fx=x-x0;fy=y-y0
    sm=lambda t:t*t*(3-2*t)
    def h(i,j): return u(i%per,j%per,seed)
    a=h(x0,y0);b=h(x0+1,y0);c=h(x0,y0+1);d=h(x0+1,y0+1)
    sx,sy=sm(fx),sm(fy)
    return (a*(1-sx)+b*sx)*(1-sy)+(c*(1-sx)+d*sx)*sy

# ---------- gloomstone 16x16 ----------
S=[(22,20,33),(30,28,44),(40,37,57),(52,48,72),(66,61,90),(82,76,108)]
img=Image.new('RGBA',(16,16))
for y in range(16):
    for x in range(16):
        n=0.55*vnoise(x/4,y/4,4,1)+0.30*vnoise(x/2,y/2,8,2)+0.15*u(x,y,3)
        n+= 0.10*math.sin((x+y)*0.9)  # faint strata
        i=min(5,max(0,int(n*6.2-0.4)))
        img.putpixel((x,y),S[i]+(255,))
# violet veins (wrapping random walks)
for k in range(3):
    x=int(u(k,10)*16);y=int(u(k,11)*16)
    for s in range(12):
        img.putpixel((x%16,y%16),(94,62,140,255))
        for dx,dy in ((1,0),(0,1)):
            p=img.getpixel(((x+dx)%16,(y+dy)%16))
            if u(x,y,k,s)<0.35: img.putpixel(((x+dx)%16,(y+dy)%16),(58,40,92,255))
        r=u(k,s,12); x+=1 if r<0.6 else 0; y+=1 if r>0.3 else 0
# pale speckles
for k in range(7):
    x=int(u(k,20)*16);y=int(u(k,21)*16)
    img.putpixel((x,y),(150,148,178,255))
img.save(R+'block/gloomstone.png')

# ---------- veilbloom 16x16 ----------
img=Image.new('RGBA',(16,16),(0,0,0,0))
P=img.putpixel
cx,cy=8.0,5.0
fill={}
for y in range(16):
    for x in range(16):
        dx,dy=x-cx+0.0,y-cy+0.0
        r=math.hypot(dx,dy); th=math.atan2(dy,dx)
        rm=2.4+1.7*abs(math.cos(2.5*th+0.3))
        if r<rm and r<4.6: fill[(x,y)]=(r,th)
for (x,y),(r,th) in fill.items():
    light=(-dx*0.0)  # placeholder
    sh=(x-cx)*-0.35+(y-cy)*-0.45   # light from top-left
    if r<1.5: col=(120,255,230) if (x,y)!=(8,5) else (214,255,248)
    elif sh>0.9: col=(244,240,255)
    elif sh>-0.4: col=(214,206,242)
    elif sh>-1.4: col=(172,160,214)
    else: col=(138,124,186)
    P((x,y),col+(255,))
for (x,y) in list(fill):
    for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
        q=(x+dx,y+dy)
        if q not in fill and 0<=q[0]<16 and 0<=q[1]<16 and img.getpixel(q)[3]==0:
            P(q,(96,84,150,255))
# stem
for y in range(9,16):
    x=7 if y<11 else 8
    P((x,y),(104,138,118,255)); P((x+1,y),(72,100,86,255))
P((8,9),(104,138,118,255))
# leaves
for (x,y,c) in [(7,13,'l'),(6,12,'l'),(5,11,'L'),(4,11,'l'),(9,12,'l'),(10,11,'L'),(11,10,'l'),(12,10,'l')]:
    P((x,y),((186,214,190,255) if c=='L' else (146,180,158,255)))
for (x,y) in [(5,12),(6,13),(10,12),(11,11)]: P((x,y),(92,122,104,255))
# glow sparkles
for (x,y) in [(3,2),(13,3),(12,8),(2,7)]: P((x,y),(150,255,235,255))
img.save(R+'block/veilbloom.png')

# ---------- entity: rift sovereign 64x64 ----------
E=Image.new('RGBA',(64,64),(0,0,0,0))
def faces(ox,oy,w,h,d):
    return {'top':(ox+d,oy,w,d),'bottom':(ox+d+w,oy,w,d),'right':(ox,oy+d,d,h),'front':(ox+d,oy+d,w,h),'left':(ox+d+w,oy+d,d,h),'back':(ox+2*d+w,oy+d,w,h)}
def shade(part,face,u_,v_,w,h,gx,gy):
    # base: pale ashen skin with dark void cracks and glowing violet seams
    n=0.6*vnoise((gx)/3.0+7,(gy)/3.0+3,64,5)+0.4*u(gx,gy,len(part))
    base=(150,146,170)
    if part=='head': base=(168,164,188)
    col=[int(c*(0.62+0.5*n)) for c in base]
    # cracks
    c=vnoise(gx/5.0,gy/5.0,64,9)
    if abs(c-0.5)<0.035: col=(70,40,130)
    if abs(c-0.5)<0.012: col=(176,110,255)
    # robe (body & legs darker with trim)
    if part in('body','rleg','lleg'):
        col=[int(x*0.38) for x in col]
        if face in('front','back') and v_%6==5: col=(96,58,168)
    if part in('rarm','larm'):
        col=[int(x*0.8) for x in col]
        if v_>=h-3: col=[int(x*0.35) for x in col]  # dark gauntlet
    return tuple(col)
def paint(part,ox,oy,w,h,d):
    for face,(fx,fy,fw,fh) in faces(ox,oy,w,h,d).items():
        for v_ in range(fh):
            for u_ in range(fw):
                gx,gy=fx+u_,fy+v_
                E.putpixel((gx,gy),shade(part,face,u_,v_,fw,fh,gx,gy)+(255,))
paint('head',0,0,8,8,8)
paint('body',16,16,8,12,4)
paint('rarm',40,16,4,12,4)
paint('rleg',0,16,4,12,4)
paint('larm',32,48,4,12,4)
paint('lleg',16,48,4,12,4)
# face: glowing eyes + jagged mouth + crown spikes on forehead
fx,fy=8,8
for y in range(8):
    for x in range(8):
        E.putpixel((fx+x,fy+y),(56,50,74,255) if y>=2 else (168,164,188,255))
for (x,y) in [(1,4),(2,4),(5,4),(6,4)]: E.putpixel((fx+x,fy+y),(214,150,255,255))
for (x,y) in [(2,4),(5,4)]: E.putpixel((fx+x,fy+y),(255,255,255,255))
for (x,y) in [(1,3),(2,3),(5,3),(6,3),(1,5),(6,5)]: E.putpixel((fx+x,fy+y),(120,60,200,255))
for x in range(2,6): E.putpixel((fx+x,fy+6),(20,14,30,255) if x%2==0 else (150,90,230,255))
# hat layer (outer head) : horns/crown
for x in range(0,32):
    pass
hx,hy=32,0
for face,(ax,ay,aw,ah) in faces(hx,hy,8,8,8).items():
    pass
for x in (2,5):  # crown spikes on top face of hat layer
    E.putpixel((hx+8+x,hy+2),(176,110,255,255)); E.putpixel((hx+8+x,hy+3),(96,58,168,255))
# (boss skin is now the hand-made rifttexture.png - not generated)

# ---------- item: provided texture ----------
src=Image.open('/mnt/user-data/uploads/deepestdarktrim__1_.png').convert('RGBA'); src.save(R+'item/rift_opener.png')
# ---------- mod icon ----------
ic=Image.new('RGBA',(128,128),(14,10,24,255))
for y in range(128):
    for x in range(128):
        d=math.hypot(x-64,y-64)/90
        c=int(max(0,1-d)*46); ic.putpixel((x,y),(14+c//2,10+c//3,24+c,255))
big=src.resize((96,96),Image.NEAREST); ic.alpha_composite(big,(16,16)); ic.save('/home/claude/Rifters/src/main/resources/assets/rifters/icon.png')
print('ok')
