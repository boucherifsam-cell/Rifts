# Rifters

Mod Fabric (Minecraft 26.x) : une tour géante dans la Pale Garden, un boss, et l'**Ouvre-faille** qui mène à ta propre caverne sculk privée.

## Contenu
- **Rift Spire** : vraie structure de worldgen (≈ 98 blocs), générée dans les Pale Gardens. `/locate structure rifters:rift_spire` la trouve ; `/place structure rifters:rift_spire ~ ~ ~` la pose pour tester. Escalier en spirale, 5 coffres de butin, arène au sommet, balcon à créneaux, flèche gothique.
- **Rift Sovereign** : boss (700 PV, modèle 3D fait main, ~4,5 blocs de haut). Il lâche l'**Ouvre-faille**.
  - Il attend **immobile dans une pose épique** (torse bombé, crâne relevé, queue dressée en sceptre) jusqu'au premier coup ; il rugit alors, repousse les joueurs proches et le combat commence. La barre de boss n'apparaît qu'à ce moment.
  - Il reste **dans l'arène** (rayon limité, ne sort ni par les portes ni par l'ouverture de l'escalier).
  - 400 PV, armure légère : la barre de vie descend à chaque coup.
  - *Balayage de queue* (au corps à corps) : il s'enroule, puis fait tourner toute sa carcasse avec la queue. Touche à 8 blocs, repousse, affaiblit.
  - *Regard de la faille* (à distance) : le crâne se renverse, une ligne d'avertissement apparaît, puis un rayon perçant part du crâne (esquivable).
  - *Appel de la faille* (sous 50 % PV) : il lévite, queue dressée comme un sceptre, côtes ouvertes, et fait sortir 3 vexes.
  - *Pas de la faille* (sous 25 % PV) : il se replie dans la faille, réapparaît derrière sa cible et enchaîne un balayage.
  - Animations : respiration et queue qui ondule au repos, démarche longue en marchant, morsure du crâne, et un effondrement à la mort.
- **Ouvre-faille** (texture « deepest dark trim ») : maintenir clic droit = animation, puis téléportation. Dans la faille : même geste pour revenir exactement où tu étais.
- **Royaume de la faille** : caverne sculk + pierre sombre (*Gloomstone*) + fleurs lumineuses (*Veilbloom*) + mousse pâle. Chaque joueur a sa caverne, ses variations propres ; on peut y construire. Couches : 4 de Gloomstone puis 2 de bedrock tout autour.
- Succès **« The Deepest and Darkest »** à la première entrée.

## Compiler
Ce code n'a PAS été compilé ni lancé dans Minecraft (aucun accès à Minecraft ici). Procédure la plus sûre :
1. Génère un projet vierge sur <https://fabricmc.net/develop/template/> (mod id `rifters`, package `dev.rifters`, Java 25, ta version de Minecraft).
2. Remplace son dossier `src/` par celui-ci, et copie `fabric.mod.json` / les versions dans `gradle.properties`.
3. `./gradlew build` → le jar est dans `build/libs/`.
4. Corrige les éventuels noms d'API (paquets `monster.zombie`, `monster.vex`, signatures de `use`/`onUseTick`/`hurtServer`…) selon les erreurs du compilateur : ils ont été écrits pour la 26.x mais pas vérifiés.

## À savoir
- Les tours n'apparaissent que dans des **chunks nouvellement générés** : sur un monde déjà exploré, va dans une Pale Garden jamais visitée (ou crée un nouveau monde), ou utilise `/place structure`.
- La logique de génération (tour + caverne) a été testée en simulation : on peut monter de la porte à l'arène, les coffres sont accessibles, la zone du boss est dégagée.
- « Dimension par joueur » = une dimension partagée `rifters:rift_realm` où chaque joueur a une caverne scellée loin des autres (160 blocs d'écart).
- Le skin du boss est ta `rifttexture.png` (128x128, UV en 64x64 : Minecraft l'affiche en 2x). Autres textures générées par script (`tools/gen_tex.py`) ; l'icône de l'objet vient de ton fichier.
- Licence MIT : fais-en ce que tu veux.
